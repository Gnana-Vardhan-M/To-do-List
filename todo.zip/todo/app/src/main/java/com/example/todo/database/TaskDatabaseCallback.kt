package com.example.todo.database

import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class TaskDatabaseCallback(private val scope: CoroutineScope) : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        // Add any initialization logic you need when the database is created
        // For example, you might insert some initial data.
        scope.launch {
            // Insert your initialization logic here
        }
    }
}
