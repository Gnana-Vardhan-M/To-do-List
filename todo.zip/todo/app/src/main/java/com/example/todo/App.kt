package com.example.todo

import android.app.Application
import com.example.todo.database.TaskDatabase
import com.example.todo.repository.TaskRepository
import com.example.todo.viewmodel.TaskViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob


class App : Application() {

    // Use a SupervisorJob to ensure that all child coroutines are cancelled if any one of them fails
    private val applicationScope = CoroutineScope(SupervisorJob())

    // by lazy() ensures that the database and repository are only created when they are needed
    // Correct usage
    private val database = {TaskDatabase.getDatabase(this, applicationScope)}
    private val repository by lazy { TaskRepository(database.TaskDao()) }
    val viewmodel by lazy { TaskViewModel(repository) }

}
